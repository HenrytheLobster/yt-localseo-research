"""
policy.py — Scoring Policy Generator  (v2)
============================================
Generates config/scoring_policy.json from the knowledge base.

Changes from v1:
- Rules tagged with confidence: high | medium | low based on support_count
  AND creator diversity (items seen from multiple channels are more trustworthy)
- Only high/medium confidence rules go into the active policy
- Low-confidence rules go into "candidate_rules" (shown in report, not applied)
- Recommended thresholds only computed from high-confidence heuristics

Usage:
    python policy.py
    python policy.py --min_support 2
    python policy.py --include-low     # include low-confidence in active policy
"""

import argparse
import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"
KNOWLEDGE_DIR = DATA_DIR / "knowledge"
CONFIG_DIR = ROOT / "config"
POLICY_FILE = CONFIG_DIR / "scoring_policy.json"

POLICY_VERSION = "2.0"

# Support thresholds for confidence tiers
HIGH_CONFIDENCE_MIN = 3     # seen in 3+ videos
MEDIUM_CONFIDENCE_MIN = 2   # seen in 2 videos
# LOW = anything below medium (1 video)

# Only apply rules at or above this tier automatically
AUTO_APPLY_MIN_CONFIDENCE = "medium"
CONFIDENCE_RANK = {"high": 3, "medium": 2, "low": 1}


def iso_now():
    return datetime.utcnow().isoformat()


def load_knowledge(section: str) -> list[dict]:
    path = KNOWLEDGE_DIR / f"{section}.jsonl"
    if not path.exists():
        return []
    items = []
    for line in path.read_text().splitlines():
        if line.strip():
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return items


# ─── confidence scoring ───────────────────────────────────────────────────────

def count_unique_creators(item: dict, raw_dir: Path) -> int:
    """
    Count distinct channels in the provenance of an item.
    Higher diversity = more trustworthy signal.
    """
    channels = set()
    for vid_id in item.get("provenance", []):
        meta_file = raw_dir / vid_id / "meta.json"
        if meta_file.exists():
            try:
                meta = json.loads(meta_file.read_text())
                ch = meta.get("channel", "")
                if ch:
                    channels.add(ch)
            except Exception:
                pass
    return max(len(channels), 1)   # at least 1 if we have no meta


def assign_confidence(item: dict, raw_dir: Path) -> str:
    """
    Assign confidence tier based on:
    - support_count (how many videos mentioned it)
    - creator diversity (how many distinct channels)
    """
    support = item.get("support_count", 1)
    creators = count_unique_creators(item, raw_dir)

    # High: seen 3+ times, or 2+ times from different creators
    if support >= HIGH_CONFIDENCE_MIN or (support >= 2 and creators >= 2):
        return "high"
    # Medium: seen twice (even same creator)
    if support >= MEDIUM_CONFIDENCE_MIN:
        return "medium"
    return "low"


# ─── rule builders ────────────────────────────────────────────────────────────

def build_rules(
    heuristics: list[dict],
    raw_dir: Path,
    action_filter: set[str],
    active_only: bool = True,
) -> tuple[list[dict], list[dict]]:
    """
    Returns (active_rules, candidate_rules).
    active_rules = high or medium confidence.
    candidate_rules = low confidence (show in report, don't apply).
    """
    active, candidates = [], []

    for h in heuristics:
        if h.get("action") not in action_filter:
            continue
        confidence = assign_confidence(h, raw_dir)
        rule = {
            "name": h.get("name", "unnamed"),
            "condition": h.get("condition", ""),
            "machine_rule": h.get("machine_rule", {}),
            "weight": h.get("weight", 0.5),
            "support_count": h.get("support_count", 1),
            "confidence": confidence,
            "provenance": h.get("provenance", []),
        }
        if CONFIDENCE_RANK[confidence] >= CONFIDENCE_RANK[AUTO_APPLY_MIN_CONFIDENCE]:
            active.append(rule)
        else:
            candidates.append(rule)

    active.sort(key=lambda r: (-CONFIDENCE_RANK[r["confidence"]], -r["support_count"], -r["weight"]))
    candidates.sort(key=lambda r: -r["support_count"])
    return active, candidates


def build_filter_rules(heuristics: list[dict], claims: list[dict], raw_dir: Path) -> list[dict]:
    rules = []
    for h in heuristics:
        if h.get("action") != "flag":
            continue
        confidence = assign_confidence(h, raw_dir)
        if CONFIDENCE_RANK[confidence] >= CONFIDENCE_RANK[AUTO_APPLY_MIN_CONFIDENCE]:
            rules.append({
                "name": h.get("name", ""),
                "condition": h.get("condition", ""),
                "machine_rule": h.get("machine_rule", {}),
                "confidence": confidence,
                "source": "heuristic",
            })
    for c in claims:
        if c.get("category") == "risk":
            confidence = assign_confidence(c, raw_dir)
            if confidence == "high":
                rules.append({
                    "name": c.get("statement", "")[:60],
                    "condition": c.get("statement", ""),
                    "machine_rule": {},
                    "confidence": confidence,
                    "source": "claim",
                    "provenance": c.get("provenance", []),
                })
    return rules


def compute_thresholds(heuristics: list[dict], raw_dir: Path) -> dict:
    """Only use high-confidence heuristics for threshold recommendations."""
    field_values: dict[str, list[tuple[float, int]]] = {}

    for h in heuristics:
        confidence = assign_confidence(h, raw_dir)
        if confidence != "high":
            continue
        rule = h.get("machine_rule", {})
        field = rule.get("field", "")
        value = rule.get("value")
        support = h.get("support_count", 1)
        if field and value is not None:
            try:
                field_values.setdefault(field, []).append((float(value), support))
            except (TypeError, ValueError):
                continue

    thresholds = {}
    for field, vals in field_values.items():
        total_w = sum(s for _, s in vals)
        thresholds[field] = round(sum(v * s for v, s in vals) / total_w, 2)
    return thresholds


def summarize(items: list[dict], raw_dir: Path, key_fields: list[str], top_n: int) -> list[str]:
    enriched = [(item, assign_confidence(item, raw_dir)) for item in items]
    enriched.sort(key=lambda x: (-CONFIDENCE_RANK[x[1]], -x[0].get("support_count", 1)))
    result = []
    for item, conf in enriched[:top_n]:
        name = next((item.get(f, "") for f in key_fields if item.get(f)), "")
        desc = item.get("description") or item.get("condition") or item.get("why_it_works", "")
        support = item.get("support_count", 1)
        result.append(f"[{conf}/{support}x] {name}: {desc[:120]}")
    return result


def collect_source_videos(*sections: list[dict]) -> list[str]:
    seen = set()
    for section in sections:
        for item in section:
            seen.update(item.get("provenance", []))
    return sorted(seen)


# ─── main ────────────────────────────────────────────────────────────────────

def generate_policy(include_low: bool = False) -> dict:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    raw_dir = DATA_DIR / "youtube" / "raw"

    tactics = load_knowledge("tactics")
    heuristics = load_knowledge("heuristics")
    claims = load_knowledge("claims")
    niche_patterns = load_knowledge("niche_patterns")

    if not any([tactics, heuristics, claims, niche_patterns]):
        print("⚠️  Knowledge base is empty. Run extract.py + merge.py first.")
        return {}

    print(f"📚 {len(tactics)} tactics | {len(heuristics)} heuristics | "
          f"{len(claims)} claims | {len(niche_patterns)} patterns")

    if include_low:
        global AUTO_APPLY_MIN_CONFIDENCE
        AUTO_APPLY_MIN_CONFIDENCE = "low"

    boost_active, boost_candidates = build_rules(heuristics, raw_dir, {"boost"})
    penalty_active, penalty_candidates = build_rules(heuristics, raw_dir, {"penalize", "skip"})
    filter_rules = build_filter_rules(heuristics, claims, raw_dir)
    all_candidates = boost_candidates + penalty_candidates
    thresholds = compute_thresholds(heuristics, raw_dir)

    tactics_summary = summarize(tactics, raw_dir, ["name"], top_n=8)
    patterns_summary = summarize(niche_patterns, raw_dir,
                                  ["pattern_template"], top_n=5)

    notable_claims = [
        c for c in claims
        if assign_confidence(c, raw_dir) == "high"
    ]
    notes = "; ".join(c.get("statement", "") for c in notable_claims[:5])

    source_videos = collect_source_videos(tactics, heuristics, claims, niche_patterns)

    policy = {
        "version": POLICY_VERSION,
        "generated_at": iso_now(),
        "auto_apply_min_confidence": AUTO_APPLY_MIN_CONFIDENCE,
        "based_on_video_count": len(source_videos),
        "based_on_videos": source_videos,
        "recommended_thresholds": thresholds,
        # Score delta scale — edit to match your pipeline's score range:
        #   0-1 scale   → delta_scale: 0.10  (default)
        #   0-10 scale  → delta_scale: 1.0
        #   0-100 scale → delta_scale: 10.0
        "delta_scale": 0.10,
        # Score max — used to clamp boosted scores. Match your pipeline:
        #   0-1 scale   → score_max: 1.0   (default)
        #   0-10 scale  → score_max: 10.0
        #   0-100 scale → score_max: 100.0
        "score_max": 1.0,
        # Active rules (applied automatically)
        "boost_rules": boost_active,
        "penalty_rules": penalty_active,
        "filter_rules": filter_rules,
        # Candidate rules (shown in report only — not auto-applied yet)
        "candidate_rules": all_candidates,
        "top_tactics_summary": tactics_summary,
        "top_patterns_summary": patterns_summary,
        "raw_counts": {
            "tactics": len(tactics),
            "heuristics": len(heuristics),
            "claims": len(claims),
            "niche_patterns": len(niche_patterns),
        },
        "notes": notes,
    }

    POLICY_FILE.write_text(json.dumps(policy, indent=2))
    print(f"\n✅ Policy → {POLICY_FILE}")
    print(f"   Active:     {len(boost_active)} boost | {len(penalty_active)} penalty | {len(filter_rules)} filters")
    print(f"   Candidates: {len(all_candidates)} (low-confidence, report only)")
    print(f"   Thresholds: {thresholds}")
    return policy


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--include-low", action="store_true",
                        help="Include low-confidence rules in active policy")
    args = parser.parse_args()
    generate_policy(include_low=args.include_low)
